import hashlib
import math
import os
import re
from pathlib import Path

KNOWLEDGE_DIR = Path(__file__).resolve().parents[2] / "knowledge"
RAG_DB_PATH = os.getenv("RAG_DB_PATH", str(Path(__file__).resolve().parents[1] / "chroma"))


def chunks(text, size=700, overlap=100):
    paragraphs = [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]
    result, current = [], ""
    for paragraph in paragraphs:
        if current and len(current) + len(paragraph) + 2 > size:
            result.append(current)
            current = current[-overlap:] + "\n\n" + paragraph
        else:
            current = f"{current}\n\n{paragraph}".strip()
    if current: result.append(current)
    return result


def embed(text, dimensions=256):
    vector = [0.0] * dimensions
    for token in re.findall(r"[a-z0-9]+", text.lower()):
        digest = hashlib.sha256(token.encode()).digest()
        index = int.from_bytes(digest[:4], "little") % dimensions
        vector[index] += -1.0 if digest[4] & 1 else 1.0
    norm = math.sqrt(sum(value * value for value in vector)) or 1.0
    return [value / norm for value in vector]


def _collection():
    import chromadb
    client = chromadb.PersistentClient(path=RAG_DB_PATH)
    return client.get_or_create_collection("mentora_knowledge", metadata={"hnsw:space":"cosine"})


def ingest(force=False):
    collection = _collection()
    if force:
        existing = collection.get()
        if existing["ids"]: collection.delete(ids=existing["ids"])
    elif collection.count() > 0:
        return collection.count()
    ids, documents, metadatas, embeddings = [], [], [], []
    for path in sorted(KNOWLEDGE_DIR.rglob("*.md")):
        for index, text in enumerate(chunks(path.read_text(encoding="utf-8"))):
            ids.append(hashlib.sha256(f"{path}:{index}:{text}".encode()).hexdigest()[:24])
            documents.append(text); metadatas.append({"source":path.name,"topic":path.parent.name}); embeddings.append(embed(text))
    if documents: collection.add(ids=ids, documents=documents, metadatas=metadatas, embeddings=embeddings)
    return len(documents)


def retrieve(query, limit=3):
    try:
        collection = _collection()
        if collection.count() == 0: ingest()
        result = collection.query(query_embeddings=[embed(query)], n_results=min(limit, max(collection.count(), 1)))
        return [{"text":text,"source":meta["source"],"topic":meta["topic"]} for text,meta in zip(result["documents"][0], result["metadatas"][0])]
    except Exception as exc:
        raise RuntimeError(f"Knowledge retrieval failed: {exc}") from exc
