import re

from .content import PROJECTS, UPDATES
from .providers import DemoProvider, ProviderError, get_provider


def choose_agent(message: str):
    text = message.lower()
    if any(x in text for x in ["career", "job", "become", "skill gap", "interview", "certification"]): return "Career Coach"
    if any(x in text for x in ["quiz", "test me", "question"]): return "Quiz Master"
    if any(x in text for x in ["project", "portfolio", "build"]): return "Project Guide"
    if any(x in text for x in ["latest", "research", "news", "update"]): return "Researcher"
    if any(x in text for x in ["remind", "schedule"]): return "Reminder"
    return "Tutor"


def _grounded_demo_answer(message: str, retrieved: list[dict]) -> str:
    query_terms = set(re.findall(r"[a-z0-9]+", message.lower())) - {
        "a", "an", "and", "explain", "how", "in", "is", "me", "simply", "the", "to", "what",
    }
    candidates = []
    for chunk in retrieved:
        for sentence in re.split(r"(?<=[.!?])\s+", chunk["text"]):
            clean = sentence.strip().lstrip("# ")
            terms = set(re.findall(r"[a-z0-9]+", clean.lower()))
            score = len(query_terms & terms)
            if score and clean:
                candidates.append((score, clean))
    candidates.sort(key=lambda item: (-item[0], len(item[1])))
    selected = []
    best_score = candidates[0][0] if candidates else 0
    for score, sentence in candidates:
        if score < best_score:
            break
        if sentence not in selected:
            selected.append(sentence)
        if len(selected) == 2:
            break
    if selected:
        return " ".join(selected)
    return "I could not find a sufficiently relevant grounded lesson. Try asking about Python, DSA, SQL, machine learning, web development, data science, or generative AI."


def run_agent(agent, message, profile, retrieved):
    provider = get_provider()
    context = "\n\n".join(chunk["text"] for chunk in retrieved)
    learner = f"Career goal: {profile.career_goal}; experience: {profile.experience_level}; skills: {', '.join(profile.skills or [])}."
    if isinstance(provider, DemoProvider):
        if agent == "Tutor":
            return _grounded_demo_answer(message, retrieved)
        if agent == "Quiz Master": return "Open Adaptive Quiz to start a persisted, scored quiz whose difficulty changes with your performance."
        if agent == "Career Coach": return f"For your {profile.career_goal} goal, use Career & Projects for a computed skill-gap plan based on your saved skills."
        if agent == "Project Guide": return f"A useful next project is {PROJECTS[1]['title']}: {PROJECTS[1]['description']}"
        if agent == "Researcher": return UPDATES[0]["summary"]
        return "Open Reminders to create a persistent learning reminder."
    prompts = {
        "Tutor": "Teach clearly at the learner's stated level. Use only the retrieved context for factual claims and say when context is insufficient.",
        "Quiz Master": "Guide the learner to the adaptive quiz feature; do not invent an unscored quiz in chat.",
        "Career Coach": "Give concise, actionable career guidance grounded in the learner profile.",
        "Project Guide": "Recommend one feasible portfolio project and explain why it fits the learner.",
        "Researcher": "Summarize the supplied research update without inventing facts.",
        "Reminder": "Help the learner phrase a concrete reminder; do not claim it was saved.",
    }
    return provider.generate(prompts[agent], f"{learner}\nRetrieved context:\n{context}\nLearner request: {message}")
