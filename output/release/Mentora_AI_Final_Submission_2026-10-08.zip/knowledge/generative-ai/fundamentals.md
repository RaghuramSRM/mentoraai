# Generative AI and RAG

Embeddings represent semantic content as numerical vectors. Retrieval-augmented generation searches a trusted corpus for relevant passages, then supplies those passages to a language model as context.

A grounded answer should be supported by retrieved sources. Evaluation should measure retrieval relevance, answer correctness, groundedness and whether citations actually support the claims.
