# Python Fundamentals

Python functions are defined with `def`. Parameters receive inputs and `return` sends a value back. Lists preserve order and allow duplicates, while sets store unique values. Dictionaries map keys to values.

Generators use `yield` to produce values lazily. Calling a generator function returns an iterator, which is useful when a full result would consume too much memory.
