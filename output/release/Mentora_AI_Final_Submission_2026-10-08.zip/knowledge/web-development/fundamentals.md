# Web Development Fundamentals

HTTP GET retrieves resources, POST commonly creates resources, PATCH partially updates them and DELETE removes them. Idempotent operations have the same intended server effect when repeated.

React interfaces derive output from props and state. State should be treated immutably so changes are detected predictably. Accessible forms require associated labels, keyboard operation and clear error messages.
