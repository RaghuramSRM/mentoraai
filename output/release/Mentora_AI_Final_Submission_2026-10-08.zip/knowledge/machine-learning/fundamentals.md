# Machine Learning Fundamentals

Overfitting occurs when a model learns training noise and fails to generalize. Use a validation split for model decisions and preserve the test set for final evaluation.

Cross-validation evaluates a model across multiple data splits. Useful metrics depend on the goal: precision and recall matter for imbalanced classification, while MAE and RMSE describe regression error.
