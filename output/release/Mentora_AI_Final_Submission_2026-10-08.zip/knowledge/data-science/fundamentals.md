# Data Science Fundamentals

Data science combines data cleaning, exploratory analysis, statistics and communication. The median is more robust to extreme values than the mean.

Data leakage occurs when training features contain information that would not exist at prediction time. A reproducible workflow documents transformations and separates training, validation and test data.
