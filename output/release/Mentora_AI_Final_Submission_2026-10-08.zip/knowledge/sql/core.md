# SQL Core Skills

`WHERE` filters rows before grouping. `HAVING` filters groups after aggregation. A `LEFT JOIN` preserves every row from the left table and attaches matching right-side rows.

Window functions calculate values across related rows without collapsing them. `ROW_NUMBER()` assigns a unique sequence within a partition and ordering.
