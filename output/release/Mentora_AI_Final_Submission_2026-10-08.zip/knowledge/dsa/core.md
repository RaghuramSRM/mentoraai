# Data Structures and Algorithms

Binary search repeatedly halves a sorted search space and runs in O(log n) time. Hash tables provide average O(1) lookup when keys are distributed well.

Dijkstra's shortest-path algorithm assumes non-negative edge weights. Breadth-first search finds shortest paths in unweighted graphs.
